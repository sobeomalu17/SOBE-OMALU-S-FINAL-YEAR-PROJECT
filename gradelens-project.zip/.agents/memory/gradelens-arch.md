---
name: GradeLens Architecture
description: Key decisions for the GradeLens student grade dashboard project.
---

## Auth
- JWT stored in `localStorage` key `gradelens_token`; sent as `Authorization: Bearer` header.
- JWT signed with `process.env.SESSION_SECRET`.
- Auth middleware: `artifacts/api-server/src/middlewares/auth.ts`; extends `Request` as `AuthRequest`.

## Grade Scale
- Nigerian 5.0 system: A=5, B=4, C=3, D=2, E=1, F=0.
- GPA calculation in `artifacts/api-server/src/lib/gpa.ts`.
- Degree class thresholds: First Class ≥4.5, 2nd Upper ≥3.5, 2nd Lower ≥2.4, Third ≥1.5, Pass ≥1.0.

## Zod Schema Names (from codegen)
- Generated schemas use PascalCase + Body suffix: `RegisterBody`, `LoginBody`, `CreateSemesterBody`, `AddCourseBody`, `UpdateCourseBody`, `PredictGpaBody`, `CalculateTargetBody`, `UpdateSettingsBody`.
- Import from `@workspace/api-zod`.

## Routes
- GPA recalculates via `recalculateSemesterGpa()` exported from `semesters.ts` and called in courses.ts.
- All routes mounted under `/api` in `artifacts/api-server/src/routes/index.ts`.

## Frontend
- Router: Wouter with `base={import.meta.env.BASE_URL.replace(/\/$/, "")}`.
- API calls use `import.meta.env.BASE_URL` prefix in `artifacts/gradelens/src/lib/api.ts`.
- Auth redirects must use `useEffect` (not render-time setLocation) to avoid React setState-in-render errors.
- Charts: Recharts only.

**Why:** The `setLocation` inside render body causes React warning; must be in `useEffect`.
