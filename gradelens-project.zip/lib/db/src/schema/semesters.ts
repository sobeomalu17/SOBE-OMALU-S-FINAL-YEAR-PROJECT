import { pgTable, serial, integer, text, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const semestersTable = pgTable("semesters", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  academicYear: text("academic_year").notNull(),
  semesterType: text("semester_type").notNull(),
  semesterGpa: numeric("semester_gpa", { precision: 4, scale: 2 }).notNull().default("0.00"),
  totalCredits: integer("total_credits").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSemesterSchema = createInsertSchema(semestersTable).omit({
  id: true,
  semesterGpa: true,
  totalCredits: true,
  createdAt: true,
});
export type InsertSemester = z.infer<typeof insertSemesterSchema>;
export type Semester = typeof semestersTable.$inferSelect;
