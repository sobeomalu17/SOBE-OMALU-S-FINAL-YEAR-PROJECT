import { pgTable, serial, integer, text, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { semestersTable } from "./semesters";

export const coursesTable = pgTable("courses", {
  id: serial("id").primaryKey(),
  semesterId: integer("semester_id")
    .notNull()
    .references(() => semestersTable.id, { onDelete: "cascade" }),
  courseCode: text("course_code").notNull(),
  courseTitle: text("course_title").notNull(),
  creditHours: integer("credit_hours").notNull(),
  gradeReceived: text("grade_received").notNull(),
  gradePoints: numeric("grade_points", { precision: 4, scale: 2 }).notNull(),
  courseType: text("course_type").notNull().default("Required"),
});

export const insertCourseSchema = createInsertSchema(coursesTable).omit({
  id: true,
  gradePoints: true,
});
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof coursesTable.$inferSelect;
