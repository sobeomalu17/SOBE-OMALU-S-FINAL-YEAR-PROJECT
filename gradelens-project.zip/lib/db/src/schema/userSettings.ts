import { pgTable, serial, integer, text, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const userSettingsTable = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .unique()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  gradingScale: text("grading_scale").notNull().default("5.0"),
  theme: text("theme").notNull().default("light"),
  highContrast: boolean("high_contrast").notNull().default(false),
  largeText: boolean("large_text").notNull().default(false),
  gpaNotifications: boolean("gpa_notifications").notNull().default(true),
  milestoneNotifications: boolean("milestone_notifications").notNull().default(true),
});

export const insertUserSettingsSchema = createInsertSchema(userSettingsTable).omit({
  id: true,
});
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettingsTable.$inferSelect;
