import { useEffect, useState } from "react";
import { api, type PerformanceData } from "@/lib/api";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell,
} from "recharts";

const BAR_COLORS = ["#6366f1", "#6366f1", "#a5b4fc", "#6366f1", "#a5b4fc", "#6366f1"];

export default function AnalyticsPage() {
  const [perf, setPerf] = useState<PerformanceData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<PerformanceData>("/analytics/performance")
      .then(setPerf)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center py-24">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
    </div>
  );

  const latestSemLabel = perf?.gpaTrend?.[perf.gpaTrend.length - 1]?.label ?? "Latest Semester";

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Performance Analytics</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Visual breakdown of your academic performance</p>
      </div>

      {/* Full-width GPA Trend */}
      <div className="bg-card rounded-xl border border-card-border p-5">
        <div className="mb-4">
          <h2 className="font-semibold text-base">Cumulative GPA Trend</h2>
          <p className="text-xs text-muted-foreground">
            Tracking progression across {perf?.gpaTrend?.length ?? 0} completed semester{perf?.gpaTrend?.length !== 1 ? "s" : ""}
          </p>
        </div>
        {(perf?.gpaTrend?.length ?? 0) > 0 ? (
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={perf!.gpaTrend} margin={{ top: 24, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="cgpaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.18} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0.01} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9ca3af" }} />
              <YAxis domain={["auto", "auto"]} tick={{ fontSize: 11, fill: "#9ca3af" }} />
              <Tooltip
                formatter={(v: number) => [v.toFixed(2), "CGPA"]}
                contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 12 }}
              />
              <Area
                type="monotone"
                dataKey="gpa"
                stroke="#6366f1"
                strokeWidth={2.5}
                fill="url(#cgpaGrad)"
                dot={{ r: 4, fill: "#6366f1", strokeWidth: 0 }}
                activeDot={{ r: 6, fill: "#6366f1" }}
                label={{ position: "top", fontSize: 10, fill: "#6366f1", formatter: (v: number) => v.toFixed(2) }}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">No data yet</div>
        )}
      </div>

      {/* Two columns: Course Performance + Performance Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Course Performance Bar Chart */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-base">Course Performance — {latestSemLabel}</h2>
            <p className="text-xs text-muted-foreground">Grade points earned per course (5.0 scale)</p>
          </div>
          {(perf?.semesterPerformance?.length ?? 0) > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={perf!.semesterPerformance} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="courseCode" tick={{ fontSize: 10, fill: "#9ca3af" }} />
                <YAxis domain={[0, 5]} tick={{ fontSize: 10, fill: "#9ca3af" }} ticks={[0, 1, 2, 3, 4, 5]} />
                <Tooltip
                  formatter={(v: number) => [v.toFixed(1), "Grade Points"]}
                  contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 12 }}
                />
                <Bar dataKey="gradePoints" radius={[4, 4, 0, 0]} label={{ position: "top", fontSize: 10, fill: "#6366f1", formatter: (v: number) => v.toFixed(1) }}>
                  {perf!.semesterPerformance.map((_, i) => (
                    <Cell key={i} fill={BAR_COLORS[i % BAR_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No course data</div>
          )}
        </div>

        {/* Performance Summary */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-base">Performance Summary</h2>
            <p className="text-xs text-muted-foreground">Automatically computed insights</p>
          </div>
          <div className="space-y-0 divide-y divide-border">
            {[
              {
                label: "Best performing course",
                value: perf?.bestCourse
                  ? `${perf.bestCourse.courseCode} (A, ${perf.bestCourse.gradePoints.toFixed(1)})`
                  : "—",
                valueColor: "text-green-600 font-semibold",
              },
              {
                label: "Needs attention",
                value: perf?.weakestCourse
                  ? `${perf.weakestCourse.courseCode} (${perf.weakestCourse.gradePoints >= 4 ? "B" : perf.weakestCourse.gradePoints >= 3 ? "C" : "D"}, ${perf.weakestCourse.gradePoints.toFixed(1)})`
                  : "—",
                valueColor: "text-orange-500 font-semibold",
              },
              {
                label: "Overall trend",
                value: perf?.trend === "improving"
                  ? "▲ Improving"
                  : perf?.trend === "declining"
                  ? "▼ Declining"
                  : "→ Stable",
                valueColor: perf?.trend === "improving"
                  ? "text-green-600 font-semibold"
                  : perf?.trend === "declining"
                  ? "text-red-500 font-semibold"
                  : "text-muted-foreground font-semibold",
              },
              {
                label: "Best semester",
                value: (() => {
                  if (!perf?.gpaTrend?.length) return "—";
                  const best = [...perf.gpaTrend].sort((a, b) => b.gpa - a.gpa)[0];
                  return `${best.label} (${best.gpa.toFixed(2)})`;
                })(),
                valueColor: "font-semibold",
              },
              {
                label: "Credit load this term",
                value: perf?.semesterPerformance?.length
                  ? `${perf.semesterPerformance.reduce((s, c) => s + c.creditHours, 0)} units`
                  : "—",
                valueColor: "font-semibold",
              },
            ].map(({ label, value, valueColor }) => (
              <div key={label} className="flex items-center justify-between py-3">
                <span className="text-sm text-muted-foreground">{label}</span>
                <span className={`text-sm ${valueColor}`}>{value}</span>
              </div>
            ))}
          </div>

          {/* CGPA badge */}
          <div className="mt-4 p-4 rounded-lg bg-primary/5 border border-primary/20 text-center">
            <p className="text-xs text-primary/70 font-medium uppercase tracking-wider">Current CGPA</p>
            <p className="text-4xl font-bold text-primary mt-1">{(perf?.cgpa ?? 0).toFixed(2)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
