import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { api, type OverviewData, type Semester } from "@/lib/api";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";

const DONUT_COLORS = ["#6366f1", "#818cf8", "#a5b4fc", "#c7d2fe", "#e0e7ff"];
const GRADE_LABELS = ["A grades", "B grades", "C grades", "D grades", "E/F grades"];

function StatCard({
  label, value, sub, subColor = "text-green-500", bottom,
}: {
  label: string; value: React.ReactNode; sub?: string; subColor?: string; bottom?: React.ReactNode;
}) {
  return (
    <div className="bg-card rounded-xl border border-card-border p-5 flex flex-col gap-2">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="text-3xl font-bold tracking-tight">{value}</p>
      {sub && <p className={`text-xs font-medium ${subColor}`}>{sub}</p>}
      {bottom}
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [overview, setOverview] = useState<OverviewData | null>(null);
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get<OverviewData>("/analytics/overview"),
      api.get<Semester[]>("/semesters"),
    ]).then(([ov, sem]) => {
      setOverview(ov);
      setSemesters(sem);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
    </div>
  );

  const trend = overview?.trend ?? "insufficient_data";
  const TrendIcon = trend === "improving" ? TrendingUp : trend === "declining" ? TrendingDown : Minus;
  const trendColor = trend === "improving" ? "text-green-500" : trend === "declining" ? "text-red-500" : "text-muted-foreground";

  // Get latest semester label
  const latestSem = semesters[semesters.length - 1];
  const levelYear = latestSem ? `${latestSem.academicYear} · ${latestSem.semesterType} Semester` : "";

  // Build donut data from grade distribution
  const donutData = (overview?.gradeDistribution ?? []).map((d, i) => ({
    name: GRADE_LABELS[i] ?? `${d.grade} grades`,
    value: d.count,
    percentage: d.percentage,
  })).filter((d) => d.value > 0);

  const cgpa = overview?.cgpa ?? 0;
  const prevCgpa = semesters.length >= 2
    ? semesters[semesters.length - 2].semesterGpa
    : null;
  const cgpaDiff = prevCgpa !== null ? cgpa - prevCgpa : null;

  const creditsEarned = overview?.totalCreditsEarned ?? 0;
  const creditsRequired = 150;
  const creditsToGrad = Math.max(0, creditsRequired - creditsEarned);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold">Academic Overview</h1>
        <p className="text-muted-foreground text-sm mt-0.5">{levelYear}</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label="Cumulative GPA"
          value={cgpa.toFixed(2)}
          sub={cgpaDiff !== null
            ? `${cgpaDiff >= 0 ? "▲" : "▼"} ${Math.abs(cgpaDiff).toFixed(2)} from last semester`
            : "No previous data"}
          subColor={cgpaDiff !== null && cgpaDiff >= 0 ? "text-green-500" : "text-red-500"}
        />
        <StatCard
          label="Semester GPA"
          value={(overview?.latestSemesterGpa ?? 0).toFixed(2)}
          sub={`▲ ${overview?.degreeClass ?? "—"} standing`}
          subColor="text-green-500"
        />
        <StatCard
          label="Credits Earned"
          value={
            <span>
              {creditsEarned}
              <span className="text-lg font-normal text-muted-foreground">/{creditsRequired}</span>
            </span>
          }
          sub={`${creditsToGrad} credits to graduation`}
          subColor="text-muted-foreground"
        />
        <StatCard
          label="Class of Degree"
          value={<span className="text-2xl">{overview?.degreeClass ?? "—"}</span>}
          sub="On track ✓"
          subColor="text-green-500"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* GPA Progression - takes 2/3 */}
        <div className="bg-card rounded-xl border border-card-border p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-1">
            <div>
              <h2 className="font-semibold text-base">GPA Progression</h2>
              <p className="text-xs text-muted-foreground">Semester-by-semester cumulative performance trend</p>
            </div>
            <div className={`flex items-center gap-1 text-xs font-medium ${trendColor}`}>
              <TrendIcon className="h-3.5 w-3.5" />
              <span className="capitalize">{trend.replace("_", " ")}</span>
            </div>
          </div>
          {(overview?.gpaTrend?.length ?? 0) > 0 ? (
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={overview!.gpaTrend} margin={{ top: 20, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="gpaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9ca3af" }} />
                <YAxis domain={["auto", "auto"]} tick={{ fontSize: 11, fill: "#9ca3af" }} />
                <Tooltip
                  formatter={(v: number) => [v.toFixed(2), "GPA"]}
                  contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 12 }}
                />
                <Area
                  type="monotone"
                  dataKey="gpa"
                  stroke="#6366f1"
                  strokeWidth={2.5}
                  fill="url(#gpaGrad)"
                  dot={{ r: 4, fill: "#6366f1", strokeWidth: 0 }}
                  activeDot={{ r: 6, fill: "#6366f1" }}
                  label={{ position: "top", fontSize: 10, fill: "#6366f1", formatter: (v: number) => v.toFixed(2) }}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
              Add courses to see your GPA trend
            </div>
          )}
        </div>

        {/* Grade Distribution - takes 1/3 */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-1">
            <h2 className="font-semibold text-base">Grade Distribution</h2>
            <p className="text-xs text-muted-foreground">Across all completed courses</p>
          </div>
          {donutData.length > 0 ? (
            <div className="flex flex-col items-center">
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie
                    data={donutData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={48}
                    outerRadius={72}
                    paddingAngle={2}
                    label={false}
                  >
                    {donutData.map((_, i) => (
                      <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number, name: string) => [v, name]} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
              {/* Center label overlay */}
              <div className="space-y-1 w-full mt-1">
                {donutData.map((d, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-sm" style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} />
                      <span className="text-muted-foreground">{d.name}</span>
                    </div>
                    <span className="font-medium">{d.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">No grade data yet</div>
          )}
        </div>
      </div>

      {/* Recent semesters */}
      <div className="bg-card rounded-xl border border-card-border p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-base">Recent Semesters</h2>
          <Link href="/semesters" className="text-sm text-primary hover:underline font-medium">View all</Link>
        </div>
        {semesters.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">
            No semesters yet.{" "}
            <Link href="/semesters" className="text-primary hover:underline">Add one</Link>
          </p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
            {semesters.slice(-4).reverse().map((s) => (
              <Link key={s.id} href={`/semesters/${s.id}`}
                className="p-4 rounded-lg border border-border hover:border-primary/40 hover:bg-primary/5 transition-all"
              >
                <p className="text-xs text-muted-foreground font-medium">{s.semesterType} Sem · {s.academicYear}</p>
                <p className="text-2xl font-bold mt-1">{s.semesterGpa.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.totalCredits} units</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
