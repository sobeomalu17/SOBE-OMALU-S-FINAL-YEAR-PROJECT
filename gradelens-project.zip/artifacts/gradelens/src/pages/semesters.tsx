import { useEffect, useState } from "react";
import { Link } from "wouter";
import { api, type Semester } from "@/lib/api";
import { Plus, Trash2, ChevronRight, BookOpen, AlertCircle, X } from "lucide-react";

const SEMESTER_TYPES = ["First", "Second", "Summer"];

function getDegreeClass(gpa: number) {
  if (gpa >= 4.5) return { label: "First Class", color: "bg-green-100 text-green-800" };
  if (gpa >= 3.5) return { label: "2nd Upper", color: "bg-blue-100 text-blue-800" };
  if (gpa >= 2.4) return { label: "2nd Lower", color: "bg-yellow-100 text-yellow-800" };
  if (gpa >= 1.5) return { label: "Third Class", color: "bg-orange-100 text-orange-800" };
  if (gpa >= 1.0) return { label: "Pass", color: "bg-gray-100 text-gray-700" };
  return { label: "Fail", color: "bg-red-100 text-red-800" };
}

export default function SemestersPage() {
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ academicYear: "", semesterType: "First" });
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get<Semester[]>("/semesters").then(setSemesters).finally(() => setLoading(false));
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const s = await api.post<Semester>("/semesters", form);
      setSemesters((prev) => [...prev, s]);
      setShowForm(false);
      setForm({ academicYear: "", semesterType: "First" });
    } catch (err: any) {
      setError(err.message ?? "Failed to add semester");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: number) {
    setDeleteId(id);
    setConfirmDeleteId(null);
    try {
      await api.delete(`/semesters/${id}`);
      setSemesters((prev) => prev.filter((s) => s.id !== id));
    } catch (err: any) {
      setError(err.message ?? "Failed to delete semester");
    } finally {
      setDeleteId(null);
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Semesters</h1>
          <p className="text-muted-foreground mt-0.5 text-sm">Manage your academic semesters</p>
        </div>
        <button
          onClick={() => { setShowForm(!showForm); setError(""); }}
          className="flex items-center gap-2 bg-primary text-primary-foreground rounded-md px-4 py-2 text-sm font-semibold hover:opacity-90 transition"
        >
          <Plus className="h-4 w-4" />
          Add Semester
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 px-4 py-3 rounded-lg border border-destructive/20">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span className="flex-1">{error}</span>
          <button onClick={() => setError("")}><X className="h-4 w-4" /></button>
        </div>
      )}

      {/* Add Form */}
      {showForm && (
        <div className="bg-card rounded-xl border border-card-border p-6">
          <h2 className="font-semibold mb-4">New Semester</h2>
          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Academic Year</label>
                <input
                  value={form.academicYear}
                  onChange={(e) => setForm((f) => ({ ...f, academicYear: e.target.value }))}
                  required
                  placeholder="2023/2024"
                  autoComplete="off"
                  className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Semester Type</label>
                <select
                  value={form.semesterType}
                  onChange={(e) => setForm((f) => ({ ...f, semesterType: e.target.value }))}
                  className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
                >
                  {SEMESTER_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <button type="button" onClick={() => { setShowForm(false); setError(""); }} className="px-4 py-2 rounded-md text-sm border border-input hover:bg-accent transition">Cancel</button>
              <button type="submit" disabled={submitting} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground font-semibold hover:opacity-90 transition disabled:opacity-60">
                {submitting ? "Adding…" : "Add Semester"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Semester List */}
      {loading ? (
        <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>
      ) : semesters.length === 0 ? (
        <div className="text-center py-16 bg-card rounded-xl border border-card-border">
          <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="font-medium">No semesters yet</p>
          <p className="text-sm text-muted-foreground mt-1">Add your first semester to start tracking grades</p>
        </div>
      ) : (
        <div className="space-y-3">
          {semesters.map((s) => {
            const dc = getDegreeClass(s.semesterGpa);
            const isConfirming = confirmDeleteId === s.id;
            return (
              <div key={s.id} className="bg-card rounded-xl border border-card-border p-5 flex items-center gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold">{s.semesterType} Semester</span>
                    <span className="text-muted-foreground text-sm">{s.academicYear}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${dc.color}`}>{dc.label}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{s.totalCredits} credit units</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-2xl font-bold">{s.semesterGpa.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">Semester GPA</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Link href={`/semesters/${s.id}`} className="p-2 rounded-md hover:bg-accent transition">
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                  {isConfirming ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleDelete(s.id)}
                        disabled={deleteId === s.id}
                        className="px-2 py-1 rounded text-xs bg-destructive text-white hover:opacity-90 transition disabled:opacity-50"
                      >
                        {deleteId === s.id ? "…" : "Delete"}
                      </button>
                      <button
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2 py-1 rounded text-xs border border-input hover:bg-accent transition"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmDeleteId(s.id)}
                      className="p-2 rounded-md text-destructive hover:bg-destructive/10 transition"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
