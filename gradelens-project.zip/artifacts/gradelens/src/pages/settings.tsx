import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { api, type Settings } from "@/lib/api";
import { Save, User, Bell, Sliders, AlertCircle, X } from "lucide-react";

export default function SettingsPage() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    gradeScale: "5.0",
    theme: "system",
    emailNotifications: false,
    gpaAlerts: true,
    targetCgpa: "4.5",
  });

  useEffect(() => {
    api.get<Settings>("/settings").then((s) => {
      setSettings(s);
      setForm({
        gradeScale: s.gradeScale ?? "5.0",
        theme: s.theme ?? "system",
        emailNotifications: s.emailNotifications ?? false,
        gpaAlerts: s.gpaAlerts ?? true,
        targetCgpa: s.targetCgpa ?? "4.5",
      });
    }).catch((err: any) => {
      setError(err.message ?? "Failed to load settings");
    }).finally(() => setLoading(false));
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    setError("");
    try {
      const updated = await api.patch<Settings>("/settings", form);
      setSettings(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      setError(err.message ?? "Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return (
    <div className="flex justify-center py-24">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Manage your account and preferences</p>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 px-4 py-3 rounded-lg border border-destructive/20">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span className="flex-1">{error}</span>
          <button onClick={() => setError("")}><X className="h-4 w-4" /></button>
        </div>
      )}

      {/* Profile */}
      <div className="bg-card rounded-xl border border-card-border p-6">
        <div className="flex items-center gap-3 mb-5">
          <User className="h-5 w-5 text-muted-foreground" />
          <h2 className="font-semibold">Profile</h2>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Name</p>
            <p className="font-medium mt-0.5">{user?.firstName} {user?.lastName}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Email</p>
            <p className="font-medium mt-0.5">{user?.email}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Matric Number</p>
            <p className="font-medium mt-0.5">{user?.matricNumber}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Program</p>
            <p className="font-medium mt-0.5">{user?.program}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Matric Year</p>
            <p className="font-medium mt-0.5">{user?.matricYear}</p>
          </div>
        </div>
      </div>

      {/* Preferences */}
      <form onSubmit={handleSave} className="space-y-4">
        <div className="bg-card rounded-xl border border-card-border p-6">
          <div className="flex items-center gap-3 mb-5">
            <Sliders className="h-5 w-5 text-muted-foreground" />
            <h2 className="font-semibold">Academic Preferences</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Grade Scale</label>
              <select
                value={form.gradeScale}
                onChange={(e) => setForm((f) => ({ ...f, gradeScale: e.target.value }))}
                className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="5.0">5.0 Scale (Nigerian University System)</option>
                <option value="4.0">4.0 Scale</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Target CGPA</label>
              <input
                type="number"
                value={form.targetCgpa}
                onChange={(e) => setForm((f) => ({ ...f, targetCgpa: e.target.value }))}
                min={0} max={5} step={0.01}
                autoComplete="off"
                className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <p className="text-xs text-muted-foreground mt-1">Used in planning and predictor tools</p>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Theme</label>
              <select
                value={form.theme}
                onChange={(e) => setForm((f) => ({ ...f, theme: e.target.value }))}
                className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="system">System Default</option>
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-xl border border-card-border p-6">
          <div className="flex items-center gap-3 mb-5">
            <Bell className="h-5 w-5 text-muted-foreground" />
            <h2 className="font-semibold">Notifications</h2>
          </div>
          <div className="space-y-4">
            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium">GPA Alerts</p>
                <p className="text-xs text-muted-foreground">Get notified when CGPA changes significantly</p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={form.gpaAlerts}
                onClick={() => setForm((f) => ({ ...f, gpaAlerts: !f.gpaAlerts }))}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.gpaAlerts ? "bg-primary" : "bg-muted"}`}
              >
                <span className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${form.gpaAlerts ? "translate-x-6" : "translate-x-1"}`} />
              </button>
            </label>
            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium">Email Notifications</p>
                <p className="text-xs text-muted-foreground">Receive weekly academic performance summaries</p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={form.emailNotifications}
                onClick={() => setForm((f) => ({ ...f, emailNotifications: !f.emailNotifications }))}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.emailNotifications ? "bg-primary" : "bg-muted"}`}
              >
                <span className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${form.emailNotifications ? "translate-x-6" : "translate-x-1"}`} />
              </button>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className={`w-full flex items-center justify-center gap-2 rounded-md py-2.5 text-sm font-semibold transition ${saved ? "bg-green-500 text-white" : "bg-primary text-primary-foreground hover:opacity-90"} disabled:opacity-60`}
        >
          <Save className="h-4 w-4" />
          {saving ? "Saving…" : saved ? "Saved!" : "Save Settings"}
        </button>
      </form>

      {/* Grade Scale Reference */}
      <div className="bg-card rounded-xl border border-card-border p-5">
        <h2 className="font-semibold text-sm mb-3">Nigerian University Grade Scale (5.0)</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left border-b border-border">
                <th className="pb-2 pr-4 font-medium text-muted-foreground">Grade</th>
                <th className="pb-2 pr-4 font-medium text-muted-foreground">Score Range</th>
                <th className="pb-2 pr-4 font-medium text-muted-foreground">Grade Points</th>
                <th className="pb-2 font-medium text-muted-foreground">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[["A", "70–100%", "5.0", "Excellent"], ["B", "60–69%", "4.0", "Good"], ["C", "50–59%", "3.0", "Average"], ["D", "45–49%", "2.0", "Below Average"], ["E", "40–44%", "1.0", "Poor"], ["F", "0–39%", "0.0", "Fail"]].map(([g, range, pts, desc]) => (
              <tr key={g}>
                <td className="py-2 pr-4 font-bold">{g}</td>
                <td className="py-2 pr-4 text-muted-foreground">{range}</td>
                <td className="py-2 pr-4 font-medium">{pts}</td>
                <td className="py-2 text-muted-foreground">{desc}</td>
              </tr>
            ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
