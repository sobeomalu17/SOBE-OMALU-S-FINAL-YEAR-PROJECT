import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { api, type SemesterDetail, type Course } from "@/lib/api";
import { Plus, Trash2, Pencil, ArrowLeft, Check, X, AlertCircle } from "lucide-react";

const GRADES = ["A", "B", "C", "D", "E", "F"];
const COURSE_TYPES = ["Required", "Elective", "General"];
const GRADE_COLORS: Record<string, string> = {
  A: "bg-green-100 text-green-800",
  B: "bg-blue-100 text-blue-800",
  C: "bg-yellow-100 text-yellow-800",
  D: "bg-orange-100 text-orange-800",
  E: "bg-red-100 text-red-800",
  F: "bg-gray-100 text-gray-700",
};

const emptyForm = { courseCode: "", courseTitle: "", creditHours: 3, gradeReceived: "A", courseType: "Required" };

export default function SemesterDetailPage() {
  const [, params] = useRoute("/semesters/:id");
  const semesterId = params?.id;

  const [semester, setSemester] = useState<SemesterDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });
  const [submitting, setSubmitting] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ ...emptyForm });
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!semesterId) return;
    api.get<SemesterDetail>(`/semesters/${semesterId}`).then(setSemester).finally(() => setLoading(false));
  }, [semesterId]);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await api.post<Course>(`/semesters/${semesterId}/courses`, form);
      const updated = await api.get<SemesterDetail>(`/semesters/${semesterId}`);
      setSemester(updated);
      setShowForm(false);
      setForm({ ...emptyForm });
    } catch (err: any) {
      setError(err.message ?? "Failed to add course");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(courseId: number) {
    setDeletingId(courseId);
    setConfirmDeleteId(null);
    try {
      await api.delete(`/semesters/${semesterId}/courses/${courseId}`);
      const updated = await api.get<SemesterDetail>(`/semesters/${semesterId}`);
      setSemester(updated);
    } catch (err: any) {
      setError(err.message ?? "Failed to remove course");
    } finally {
      setDeletingId(null);
    }
  }

  function startEdit(c: Course) {
    setEditId(c.id);
    setEditForm({ courseCode: c.courseCode, courseTitle: c.courseTitle, creditHours: c.creditHours, gradeReceived: c.gradeReceived, courseType: c.courseType });
  }

  async function handleEdit() {
    if (!editId) return;
    setError("");
    try {
      await api.patch<Course>(`/semesters/${semesterId}/courses/${editId}`, editForm);
      const updated = await api.get<SemesterDetail>(`/semesters/${semesterId}`);
      setSemester(updated);
      setEditId(null);
    } catch (err: any) {
      setError(err.message ?? "Failed to update course");
    }
  }

  if (loading) return <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>;
  if (!semester) return <div className="text-center py-16 text-muted-foreground">Semester not found</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <Link href="/semesters" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-3">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Semesters
        </Link>
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold">{semester.semesterType} Semester — {semester.academicYear}</h1>
            <p className="text-muted-foreground text-sm mt-0.5">{semester.totalCredits} credit units · GPA: <strong>{semester.semesterGpa.toFixed(2)}</strong></p>
          </div>
          <button
            onClick={() => { setShowForm(!showForm); setError(""); }}
            className="flex items-center gap-2 bg-primary text-primary-foreground rounded-md px-4 py-2 text-sm font-semibold hover:opacity-90 transition"
          >
            <Plus className="h-4 w-4" /> Add Course
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 px-4 py-3 rounded-lg border border-destructive/20">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span className="flex-1">{error}</span>
          <button onClick={() => setError("")}><X className="h-4 w-4" /></button>
        </div>
      )}

      {/* Add Course Form */}
      {showForm && (
        <div className="bg-card rounded-xl border border-card-border p-6">
          <h2 className="font-semibold mb-4">New Course</h2>
          <form onSubmit={handleAdd} className="space-y-4" autoComplete="off">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Course Code</label>
                <input value={form.courseCode} onChange={(e) => setForm((f) => ({ ...f, courseCode: e.target.value }))} required placeholder="CSC101" className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Credit Hours</label>
                <input type="number" value={form.creditHours} onChange={(e) => setForm((f) => ({ ...f, creditHours: parseInt(e.target.value) }))} min={1} max={6} required className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Course Title</label>
              <input value={form.courseTitle} onChange={(e) => setForm((f) => ({ ...f, courseTitle: e.target.value }))} required placeholder="Introduction to Computer Science" className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Grade</label>
                <select value={form.gradeReceived} onChange={(e) => setForm((f) => ({ ...f, gradeReceived: e.target.value }))} className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring">
                  {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Course Type</label>
                <select value={form.courseType} onChange={(e) => setForm((f) => ({ ...f, courseType: e.target.value }))} className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring">
                  {COURSE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <button type="button" onClick={() => { setShowForm(false); setError(""); }} className="px-4 py-2 rounded-md text-sm border border-input hover:bg-accent transition">Cancel</button>
              <button type="submit" disabled={submitting} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground font-semibold hover:opacity-90 transition disabled:opacity-60">
                {submitting ? "Adding…" : "Add Course"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Courses Table */}
      <div className="bg-card rounded-xl border border-card-border overflow-hidden">
        {semester.courses.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground text-sm">No courses yet. Click "Add Course" to get started.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Code</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Title</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground">Credits</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground">Grade</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground">Points</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground">Type</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {semester.courses.map((c) =>
                editId === c.id ? (
                  <tr key={c.id} className="bg-accent/30">
                    <td className="px-4 py-2"><input autoComplete="off" value={editForm.courseCode} onChange={(e) => setEditForm((f) => ({ ...f, courseCode: e.target.value }))} className="w-20 rounded border border-input px-2 py-1 text-sm" /></td>
                    <td className="px-4 py-2"><input autoComplete="off" value={editForm.courseTitle} onChange={(e) => setEditForm((f) => ({ ...f, courseTitle: e.target.value }))} className="w-full rounded border border-input px-2 py-1 text-sm" /></td>
                    <td className="px-4 py-2 text-center"><input type="number" value={editForm.creditHours} onChange={(e) => setEditForm((f) => ({ ...f, creditHours: parseInt(e.target.value) }))} min={1} max={6} className="w-14 rounded border border-input px-2 py-1 text-sm text-center" /></td>
                    <td className="px-4 py-2 text-center"><select value={editForm.gradeReceived} onChange={(e) => setEditForm((f) => ({ ...f, gradeReceived: e.target.value }))} className="rounded border border-input px-2 py-1 text-sm">{GRADES.map((g) => <option key={g}>{g}</option>)}</select></td>
                    <td className="px-4 py-2 text-center">—</td>
                    <td className="px-4 py-2 text-center"><select value={editForm.courseType} onChange={(e) => setEditForm((f) => ({ ...f, courseType: e.target.value }))} className="rounded border border-input px-2 py-1 text-sm">{COURSE_TYPES.map((t) => <option key={t}>{t}</option>)}</select></td>
                    <td className="px-4 py-2 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={handleEdit} className="p-1.5 rounded text-green-600 hover:bg-green-50"><Check className="h-4 w-4" /></button>
                        <button onClick={() => setEditId(null)} className="p-1.5 rounded text-muted-foreground hover:bg-accent"><X className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  <tr key={c.id} className="hover:bg-accent/30 transition-colors">
                    <td className="px-4 py-3 font-mono font-medium">{c.courseCode}</td>
                    <td className="px-4 py-3">{c.courseTitle}</td>
                    <td className="px-4 py-3 text-center">{c.creditHours}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${GRADE_COLORS[c.gradeReceived] ?? "bg-gray-100"}`}>{c.gradeReceived}</span>
                    </td>
                    <td className="px-4 py-3 text-center font-medium">{c.gradePoints.toFixed(1)}</td>
                    <td className="px-4 py-3 text-center text-muted-foreground text-xs">{c.courseType}</td>
                    <td className="px-4 py-3 text-right">
                      {confirmDeleteId === c.id ? (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleDelete(c.id)}
                            disabled={deletingId === c.id}
                            className="px-2 py-1 rounded text-xs bg-destructive text-white hover:opacity-90 transition disabled:opacity-50"
                          >
                            {deletingId === c.id ? "…" : "Remove"}
                          </button>
                          <button onClick={() => setConfirmDeleteId(null)} className="px-2 py-1 rounded text-xs border border-input hover:bg-accent transition">
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => startEdit(c)} className="p-1.5 rounded hover:bg-accent transition"><Pencil className="h-3.5 w-3.5" /></button>
                          <button onClick={() => setConfirmDeleteId(c.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10 transition"><Trash2 className="h-3.5 w-3.5" /></button>
                        </div>
                      )}
                    </td>
                  </tr>
                )
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* Grade Scale Reference */}
      <div className="bg-card rounded-xl border border-card-border p-5">
        <h3 className="font-semibold text-sm mb-3">Grade Scale (5.0 System)</h3>
        <div className="flex flex-wrap gap-3 text-xs">
          {[["A", "5.0", "70–100%"], ["B", "4.0", "60–69%"], ["C", "3.0", "50–59%"], ["D", "2.0", "45–49%"], ["E", "1.0", "40–44%"], ["F", "0.0", "Below 40%"]].map(([grade, pts, range]) => (
            <div key={grade} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted">
              <span className={`w-5 h-5 rounded text-center text-xs font-bold flex items-center justify-center ${GRADE_COLORS[grade]}`}>{grade}</span>
              <span className="font-medium">{pts}</span>
              <span className="text-muted-foreground">{range}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
