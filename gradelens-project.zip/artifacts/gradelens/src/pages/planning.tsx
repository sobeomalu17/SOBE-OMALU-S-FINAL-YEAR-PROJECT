import { useEffect, useState } from "react";
import { api, type PlanningData } from "@/lib/api";
import { CheckCircle2, Circle } from "lucide-react";

export default function PlanningPage() {
  const [plan, setPlan] = useState<PlanningData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<PlanningData>("/analytics/planning").then(setPlan).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center py-24">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
    </div>
  );

  if (!plan) return null;

  const progressPercent = plan.progressPercent;
  const totalRequired = plan.totalCreditsRequired;

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Academic Planning</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Track progress toward graduation requirements</p>
      </div>

      {/* Credits to Graduation */}
      <div className="bg-card rounded-xl border border-card-border p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="font-semibold text-base">Credits to Graduation</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {plan.creditsEarned} of {totalRequired} required units completed
            </p>
          </div>
          <span className="text-3xl font-bold text-primary">{progressPercent}%</span>
        </div>

        {/* Progress bar */}
        <div className="w-full h-6 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full bg-primary transition-all flex items-center justify-end pr-3"
            style={{ width: `${progressPercent}%` }}
          >
            {progressPercent > 15 && (
              <span className="text-white text-xs font-bold">{progressPercent}%</span>
            )}
          </div>
        </div>

        {/* Credit breakdowns */}
        <div className="grid grid-cols-3 gap-4 mt-4 text-sm text-muted-foreground">
          <div>
            <span className="font-medium text-foreground">Required core: </span>
            {plan.requiredCredits}/{Math.round(totalRequired * 0.73)}
          </div>
          <div>
            <span className="font-medium text-foreground">Electives: </span>
            {plan.electiveCredits}/{Math.round(totalRequired * 0.19)}
          </div>
          <div>
            <span className="font-medium text-foreground">General studies: </span>
            {plan.generalCredits}/{Math.round(totalRequired * 0.08)}
          </div>
        </div>
      </div>

      {/* Milestones + Semester Planner */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Milestones */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-base">Milestones</h2>
            <p className="text-xs text-muted-foreground">Academic standing checkpoints</p>
          </div>
          <div className="space-y-3">
            {plan.milestones.map((m) => (
              <div key={m.label} className="flex items-center gap-3">
                {m.achieved ? (
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground/40 shrink-0" />
                )}
                <div>
                  <p className={`text-sm font-medium ${m.achieved ? "text-foreground" : "text-muted-foreground"}`}>
                    {m.label}
                  </p>
                  <p className="text-xs text-muted-foreground">{m.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Semester Planner */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-base">Semester Planner</h2>
            <p className="text-xs text-muted-foreground">Provisional next-semester course selection</p>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider pb-2">Course</th>
                <th className="text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider pb-2">Units</th>
                <th className="text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider pb-2">Type</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                { code: "CSC 401", units: 6, type: "Core" },
                { code: "CSC 411", units: 3, type: "Core" },
                { code: "CSC 421", units: 3, type: "Elective" },
                { code: "CSC 431", units: 2, type: "Elective" },
              ].map((r) => (
                <tr key={r.code}>
                  <td className="py-3 text-primary font-semibold">{r.code}</td>
                  <td className="py-3 text-center">{r.units}</td>
                  <td className="py-3 text-center">
                    <span
                      className={`text-xs px-2.5 py-1 rounded font-medium ${
                        r.type === "Core"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-yellow-100 text-yellow-700"
                      }`}
                    >
                      {r.type}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Credits summary */}
          <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Planned credit load</span>
            <span className="font-bold text-primary">14 units</span>
          </div>
          <div className="mt-1 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Credits remaining</span>
            <span className="font-semibold">{plan.creditsRemaining}</span>
          </div>
        </div>
      </div>

      {/* Credit breakdown chart - visual bars */}
      <div className="bg-card rounded-xl border border-card-border p-5">
        <h2 className="font-semibold text-base mb-4">Credit Completion by Category</h2>
        <div className="space-y-4">
          {[
            { label: "Required Core", earned: plan.requiredCredits, total: Math.round(totalRequired * 0.73), color: "bg-primary" },
            { label: "Electives", earned: plan.electiveCredits, total: Math.round(totalRequired * 0.19), color: "bg-violet-400" },
            { label: "General Studies", earned: plan.generalCredits, total: Math.round(totalRequired * 0.08), color: "bg-indigo-300" },
          ].map(({ label, earned, total, color }) => {
            const pct = Math.min(100, total > 0 ? Math.round((earned / total) * 100) : 0);
            return (
              <div key={label}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="font-medium">{label}</span>
                  <span className="text-muted-foreground">{earned}/{total} units ({pct}%)</span>
                </div>
                <div className="w-full h-3 rounded-full bg-muted overflow-hidden">
                  <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
