import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Plus, Trash2 } from "lucide-react";

const GRADES = ["A", "B", "C", "D", "E", "F"];
const GRADE_POINTS: Record<string, number> = { A: 5, B: 4, C: 3, D: 2, E: 1, F: 0 };
const GRADE_COLORS: Record<string, string> = {
  A: "bg-green-500",
  B: "bg-blue-500",
  C: "bg-yellow-500",
  D: "bg-orange-500",
  E: "bg-red-500",
  F: "bg-gray-500",
};

interface PlannedCourse { courseCode: string; creditHours: number; expectedGrade: string }
interface GpaResult { projectedSemesterGpa: number; projectedCgpa: number; currentCgpa: number; totalCreditsAfter: number }

function getDegreeClass(cgpa: number) {
  if (cgpa >= 4.5) return "First Class";
  if (cgpa >= 3.5) return "Second Class Upper";
  if (cgpa >= 2.4) return "Second Class Lower";
  if (cgpa >= 1.5) return "Third Class";
  return "Pass";
}

function getDegreeColor(cgpa: number) {
  if (cgpa >= 4.5) return "text-green-600";
  if (cgpa >= 3.5) return "text-blue-600";
  if (cgpa >= 2.4) return "text-yellow-600";
  return "text-orange-600";
}

export default function PredictorPage() {
  const [courses, setCourses] = useState<PlannedCourse[]>([
    { courseCode: "", creditHours: 3, expectedGrade: "A" },
    { courseCode: "", creditHours: 3, expectedGrade: "B" },
    { courseCode: "", creditHours: 3, expectedGrade: "A" },
  ]);
  const [result, setResult] = useState<GpaResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [currentCgpa, setCurrentCgpa] = useState<number | null>(null);

  useEffect(() => {
    // Fetch current CGPA for display before user calculates
    api.post<GpaResult>("/predictor/gpa", { courses: [{ courseCode: "TEMP", courseTitle: "Temp", creditHours: 1, expectedGrade: "A" }] })
      .then((r) => setCurrentCgpa(r.currentCgpa))
      .catch(() => {});
  }, []);

  function addCourse() {
    setCourses((c) => [...c, { courseCode: "", creditHours: 3, expectedGrade: "A" }]);
  }

  function removeCourse(i: number) {
    setCourses((c) => c.filter((_, idx) => idx !== i));
  }

  function update(i: number, field: keyof PlannedCourse, value: string | number) {
    setCourses((c) => c.map((co, idx) => idx === i ? { ...co, [field]: value } : co));
  }

  async function calculate() {
    setError("");
    setLoading(true);
    try {
      const payload = courses.filter((c) => c.courseCode.trim() || c.creditHours > 0).map((c) => ({
        courseCode: c.courseCode || "COURSE",
        courseTitle: c.courseCode || "Course",
        creditHours: c.creditHours,
        expectedGrade: c.expectedGrade,
      }));
      const r = await api.post<GpaResult>("/predictor/gpa", { courses: payload });
      setResult(r);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  // Live projected semester GPA
  const liveSemGpa = (() => {
    const valid = courses.filter((c) => c.creditHours > 0);
    const totalPts = valid.reduce((s, c) => s + c.creditHours * GRADE_POINTS[c.expectedGrade], 0);
    const totalCr = valid.reduce((s, c) => s + c.creditHours, 0);
    return totalCr > 0 ? totalPts / totalCr : 0;
  })();

  const displayedProjectedGpa = result?.projectedSemesterGpa ?? liveSemGpa;
  const displayedProjectedCgpa = result?.projectedCgpa ?? null;
  const displayedCurrentCgpa = result?.currentCgpa ?? currentCgpa;

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold">GPA Predictor</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Model the impact of expected grades before results are out</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* LEFT — Projected Courses */}
        <div className="bg-card rounded-xl border border-card-border p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-base">Projected Courses</h2>
            <p className="text-xs text-muted-foreground">Enter expected grades for in-progress courses</p>
          </div>

          {/* Table header */}
          <div className="grid grid-cols-12 gap-2 mb-2">
            <p className="col-span-5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Course</p>
            <p className="col-span-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-center">Units</p>
            <p className="col-span-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-center">Expected</p>
            <p className="col-span-1" />
          </div>

          <div className="space-y-2">
            {courses.map((c, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 items-center">
                <input
                  value={c.courseCode}
                  onChange={(e) => update(i, "courseCode", e.target.value)}
                  placeholder={`CSC ${300 + i * 10 + 1}`}
                  className="col-span-5 rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/40 text-primary font-medium placeholder:text-muted-foreground/50"
                />
                <input
                  type="number"
                  value={c.creditHours}
                  onChange={(e) => update(i, "creditHours", parseInt(e.target.value) || 1)}
                  min={1} max={6}
                  className="col-span-3 rounded-lg border border-input bg-background px-2 py-2 text-sm text-center outline-none focus:ring-2 focus:ring-primary/40"
                />
                <div className="col-span-3 flex justify-center">
                  <select
                    value={c.expectedGrade}
                    onChange={(e) => update(i, "expectedGrade", e.target.value)}
                    className="w-full rounded-lg border border-input bg-background px-2 py-2 text-sm text-center outline-none focus:ring-2 focus:ring-primary/40 font-medium"
                    style={{ color: c.expectedGrade === "A" ? "#22c55e" : c.expectedGrade === "B" ? "#3b82f6" : undefined }}
                  >
                    {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <button
                  onClick={() => removeCourse(i)}
                  disabled={courses.length === 1}
                  className="col-span-1 flex justify-center p-1 rounded text-muted-foreground/50 hover:text-destructive disabled:opacity-20 transition"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={addCourse}
            className="mt-3 flex items-center gap-1.5 text-sm text-primary hover:underline font-medium"
          >
            <Plus className="h-3.5 w-3.5" /> Add course
          </button>

          {error && <p className="text-sm text-destructive mt-3">{error}</p>}

          <button
            onClick={calculate}
            disabled={loading}
            className="mt-5 w-full bg-primary text-white rounded-lg py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-60"
          >
            {loading ? "Calculating…" : "Calculate Impact on CGPA"}
          </button>
        </div>

        {/* RIGHT — Projected Outcome */}
        <div className="flex flex-col gap-4">
          {/* Main projection card */}
          <div className="bg-card rounded-xl border border-card-border p-6 text-center">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
              Projected Semester GPA
            </p>
            <p className="text-6xl font-bold text-primary">
              {displayedProjectedGpa.toFixed(2)}
            </p>
            <p className={`text-sm font-semibold mt-2 ${getDegreeColor(displayedProjectedGpa)}`}>
              {getDegreeClass(displayedProjectedGpa)} range
            </p>
          </div>

          {/* Stats breakdown */}
          <div className="bg-card rounded-xl border border-card-border p-5 space-y-0 divide-y divide-border">
            <div className="flex items-center justify-between py-3">
              <span className="text-sm text-muted-foreground">Current CGPA</span>
              <span className="text-sm font-semibold">{displayedCurrentCgpa?.toFixed(2) ?? "—"}</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-sm text-muted-foreground">Projected CGPA</span>
              <span className={`text-sm font-semibold ${displayedProjectedCgpa !== null && displayedCurrentCgpa !== null && displayedProjectedCgpa > displayedCurrentCgpa ? "text-green-600" : ""}`}>
                {displayedProjectedCgpa !== null ? (
                  <>
                    {displayedProjectedCgpa.toFixed(2)}
                    {displayedCurrentCgpa !== null && displayedProjectedCgpa > displayedCurrentCgpa && " ▲"}
                  </>
                ) : "—"}
              </span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-sm text-muted-foreground">Change</span>
              <span className={`text-sm font-semibold ${
                displayedProjectedCgpa !== null && displayedCurrentCgpa !== null
                  ? displayedProjectedCgpa - displayedCurrentCgpa >= 0 ? "text-green-600" : "text-red-500"
                  : ""
              }`}>
                {displayedProjectedCgpa !== null && displayedCurrentCgpa !== null
                  ? `${displayedProjectedCgpa - displayedCurrentCgpa >= 0 ? "+" : ""}${(displayedProjectedCgpa - displayedCurrentCgpa).toFixed(2)}`
                  : "—"}
              </span>
            </div>
            {result && (
              <div className="flex items-center justify-between py-3">
                <span className="text-sm text-muted-foreground">Total credits after</span>
                <span className="text-sm font-semibold">{result.totalCreditsAfter}</span>
              </div>
            )}
          </div>

          {/* Grade reference */}
          <div className="bg-card rounded-xl border border-card-border p-4">
            <p className="text-xs font-semibold text-muted-foreground mb-3">Grade Scale (5.0)</p>
            <div className="flex flex-wrap gap-2">
              {GRADES.map((g) => (
                <div key={g} className="flex items-center gap-1.5">
                  <div className={`w-6 h-6 rounded-full ${GRADE_COLORS[g]} flex items-center justify-center text-white text-xs font-bold`}>
                    {g}
                  </div>
                  <span className="text-xs text-muted-foreground">{GRADE_POINTS[g]}.0</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
