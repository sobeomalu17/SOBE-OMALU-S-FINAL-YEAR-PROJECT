const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const TOKEN_KEY = "gradelens_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(
  method: string,
  path: string,
  body?: unknown
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BASE}/api${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return undefined as T;

  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data as T;
}

export const api = {
  get: <T>(path: string) => request<T>("GET", path),
  post: <T>(path: string, body: unknown) => request<T>("POST", path, body),
  patch: <T>(path: string, body: unknown) => request<T>("PATCH", path, body),
  delete: <T>(path: string) => request<T>("DELETE", path),
};

export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  matricNumber: string;
  program: string;
  matricYear: number;
}

export interface Semester {
  id: number;
  userId: number;
  academicYear: string;
  semesterType: string;
  semesterGpa: number;
  totalCredits: number;
  createdAt: string;
}

export interface Course {
  id: number;
  semesterId: number;
  courseCode: string;
  courseTitle: string;
  creditHours: number;
  gradeReceived: string;
  gradePoints: number;
  courseType: string;
}

export interface SemesterDetail extends Semester {
  courses: Course[];
}

export interface OverviewData {
  cgpa: number;
  latestSemesterGpa: number;
  totalCreditsEarned: number;
  totalCourses: number;
  degreeClass: string;
  trend: string;
  gpaTrend: { label: string; gpa: number; credits: number }[];
  gradeDistribution: { grade: string; count: number; percentage: number }[];
}

export interface PerformanceData {
  cgpa: number;
  gpaTrend: { label: string; gpa: number; credits: number }[];
  gradeDistribution: { grade: string; count: number; percentage: number }[];
  bestCourse: { courseCode: string; courseTitle: string; gradePoints: number } | null;
  weakestCourse: { courseCode: string; courseTitle: string; gradePoints: number } | null;
  trend: string;
  semesterPerformance: { courseCode: string; courseTitle: string; gradePoints: number; creditHours: number }[];
}

export interface PlanningData {
  totalCreditsRequired: number;
  creditsEarned: number;
  creditsRemaining: number;
  progressPercent: number;
  requiredCredits: number;
  electiveCredits: number;
  generalCredits: number;
  milestones: { label: string; achieved: boolean; description: string }[];
}

export interface Settings {
  id: number;
  userId: number;
  gradeScale: string;
  theme: string;
  emailNotifications: boolean;
  gpaAlerts: boolean;
  targetCgpa: string | null;
}
