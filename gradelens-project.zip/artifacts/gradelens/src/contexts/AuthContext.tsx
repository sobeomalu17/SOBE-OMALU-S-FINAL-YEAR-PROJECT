import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { api, getToken, setToken, clearToken, type User } from "@/lib/api";

interface AuthContextValue {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setTokenState] = useState<string | null>(getToken());
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const t = getToken();
    if (!t) { setIsLoading(false); return; }
    api.get<User>("/auth/me")
      .then((u) => { setUser(u); setTokenState(t); })
      .catch(() => { clearToken(); setUser(null); setTokenState(null); })
      .finally(() => setIsLoading(false));
  }, []);

  function login(newToken: string, newUser: User) {
    setToken(newToken);
    setTokenState(newToken);
    setUser(newUser);
  }

  function logout() {
    clearToken();
    setUser(null);
    setTokenState(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
