import { Router } from "express";
import { db, coursesTable, semestersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { authenticateToken, type AuthRequest } from "../middlewares/auth";
import { getGradePoints } from "../lib/gpa";
import { recalculateSemesterGpa } from "./semesters";
import { AddCourseBody, UpdateCourseBody } from "@workspace/api-zod";

const router = Router();

router.post("/semesters/:semesterId/courses", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesterId = parseInt(req.params.semesterId);
    const [semester] = await db
      .select()
      .from(semestersTable)
      .where(and(eq(semestersTable.id, semesterId), eq(semestersTable.userId, req.userId!)))
      .limit(1);

    if (!semester) {
      res.status(404).json({ error: "Semester not found" });
      return;
    }

    const parsed = AddCourseBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid input" });
      return;
    }

    const { courseCode, courseTitle, creditHours, gradeReceived, courseType } = parsed.data;
    const gradePoints = getGradePoints(gradeReceived);

    const [course] = await db
      .insert(coursesTable)
      .values({ semesterId, courseCode, courseTitle, creditHours, gradeReceived, gradePoints: String(gradePoints), courseType })
      .returning();

    await recalculateSemesterGpa(semesterId);

    res.status(201).json({
      ...course,
      gradePoints: parseFloat(String(course.gradePoints)),
    });
  } catch (err) {
    req.log.error({ err }, "AddCourse error");
    res.status(500).json({ error: "Failed to add course" });
  }
});

router.patch("/semesters/:semesterId/courses/:courseId", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesterId = parseInt(req.params.semesterId);
    const courseId = parseInt(req.params.courseId);

    const [semester] = await db
      .select()
      .from(semestersTable)
      .where(and(eq(semestersTable.id, semesterId), eq(semestersTable.userId, req.userId!)))
      .limit(1);

    if (!semester) {
      res.status(404).json({ error: "Semester not found" });
      return;
    }

    const parsed = UpdateCourseBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input" });
      return;
    }

    const updates: Record<string, unknown> = { ...parsed.data };
    if (updates.gradeReceived) {
      updates.gradePoints = String(getGradePoints(updates.gradeReceived as string));
    }

    const [course] = await db
      .update(coursesTable)
      .set(updates)
      .where(and(eq(coursesTable.id, courseId), eq(coursesTable.semesterId, semesterId)))
      .returning();

    if (!course) {
      res.status(404).json({ error: "Course not found" });
      return;
    }

    await recalculateSemesterGpa(semesterId);

    res.json({
      ...course,
      gradePoints: parseFloat(String(course.gradePoints)),
    });
  } catch (err) {
    req.log.error({ err }, "UpdateCourse error");
    res.status(500).json({ error: "Failed to update course" });
  }
});

router.delete("/semesters/:semesterId/courses/:courseId", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesterId = parseInt(req.params.semesterId);
    const courseId = parseInt(req.params.courseId);

    const [semester] = await db
      .select()
      .from(semestersTable)
      .where(and(eq(semestersTable.id, semesterId), eq(semestersTable.userId, req.userId!)))
      .limit(1);

    if (!semester) {
      res.status(404).json({ error: "Semester not found" });
      return;
    }

    await db.delete(coursesTable).where(
      and(eq(coursesTable.id, courseId), eq(coursesTable.semesterId, semesterId))
    );

    await recalculateSemesterGpa(semesterId);

    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "DeleteCourse error");
    res.status(500).json({ error: "Failed to delete course" });
  }
});

export default router;
