import { Router } from "express";
import { db, semestersTable, coursesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { authenticateToken, type AuthRequest } from "../middlewares/auth";
import { calculateGpa, getDegreeClass } from "../lib/gpa";

const router = Router();

async function getUserSemestersWithCourses(userId: number) {
  const semesters = await db
    .select()
    .from(semestersTable)
    .where(eq(semestersTable.userId, userId))
    .orderBy(semestersTable.createdAt);

  const semestersWithCourses = await Promise.all(
    semesters.map(async (s) => {
      const courses = await db
        .select()
        .from(coursesTable)
        .where(eq(coursesTable.semesterId, s.id));
      return {
        ...s,
        semesterGpa: parseFloat(String(s.semesterGpa)),
        courses: courses.map((c) => ({
          ...c,
          gradePoints: parseFloat(String(c.gradePoints)),
        })),
      };
    })
  );

  return semestersWithCourses;
}

function computeCgpa(semesters: { courses: { creditHours: number; gradePoints: number }[] }[]) {
  const allCourses = semesters.flatMap((s) => s.courses);
  return calculateGpa(allCourses);
}

function computeGradeDistribution(courses: { gradeReceived: string }[]) {
  const counts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
  for (const c of courses) {
    const g = c.gradeReceived.toUpperCase().trim();
    if (g in counts) counts[g]++;
  }
  const total = courses.length;
  return Object.entries(counts)
    .filter(([, count]) => count > 0 || total === 0)
    .map(([grade, count]) => ({
      grade,
      count,
      percentage: total > 0 ? Math.round((count / total) * 1000) / 10 : 0,
    }));
}

router.get("/analytics/overview", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesters = await getUserSemestersWithCourses(req.userId!);
    const allCourses = semesters.flatMap((s) => s.courses);
    const cgpa = computeCgpa(semesters);
    const latestSemesterGpa = semesters.length > 0 ? semesters[semesters.length - 1].semesterGpa : 0;
    const totalCreditsEarned = allCourses.reduce((sum, c) => sum + c.creditHours, 0);

    const gpaTrend = semesters.map((s) => ({
      label: `${s.semesterType} ${s.academicYear}`,
      gpa: s.semesterGpa,
      credits: s.totalCredits,
    }));

    let trend: string = "insufficient_data";
    if (semesters.length >= 2) {
      const last = semesters[semesters.length - 1].semesterGpa;
      const prev = semesters[semesters.length - 2].semesterGpa;
      if (last > prev + 0.1) trend = "improving";
      else if (last < prev - 0.1) trend = "declining";
      else trend = "stable";
    }

    res.json({
      cgpa,
      latestSemesterGpa,
      totalCreditsEarned,
      totalCourses: allCourses.length,
      degreeClass: getDegreeClass(cgpa),
      trend,
      gpaTrend,
      gradeDistribution: computeGradeDistribution(allCourses),
    });
  } catch (err) {
    req.log.error({ err }, "GetOverview error");
    res.status(500).json({ error: "Failed to fetch overview" });
  }
});

router.get("/analytics/performance", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesters = await getUserSemestersWithCourses(req.userId!);
    const allCourses = semesters.flatMap((s) => s.courses);
    const cgpa = computeCgpa(semesters);

    const gpaTrend = semesters.map((s) => ({
      label: `${s.semesterType} ${s.academicYear}`,
      gpa: s.semesterGpa,
      credits: s.totalCredits,
    }));

    let bestCourse = null;
    let weakestCourse = null;
    if (allCourses.length > 0) {
      const sorted = [...allCourses].sort((a, b) => b.gradePoints - a.gradePoints);
      const best = sorted[0];
      const worst = sorted[sorted.length - 1];
      bestCourse = { courseCode: best.courseCode, courseTitle: best.courseTitle, gradePoints: best.gradePoints };
      weakestCourse = { courseCode: worst.courseCode, courseTitle: worst.courseTitle, gradePoints: worst.gradePoints };
    }

    let trend = "insufficient_data";
    if (semesters.length >= 2) {
      const last = semesters[semesters.length - 1].semesterGpa;
      const prev = semesters[semesters.length - 2].semesterGpa;
      if (last > prev + 0.1) trend = "improving";
      else if (last < prev - 0.1) trend = "declining";
      else trend = "stable";
    }

    const latestSemester = semesters[semesters.length - 1];
    const semesterPerformance = latestSemester
      ? latestSemester.courses.map((c) => ({
          courseCode: c.courseCode,
          courseTitle: c.courseTitle,
          gradePoints: c.gradePoints,
          creditHours: c.creditHours,
        }))
      : [];

    res.json({
      cgpa,
      gpaTrend,
      gradeDistribution: computeGradeDistribution(allCourses),
      bestCourse,
      weakestCourse,
      trend,
      semesterPerformance,
    });
  } catch (err) {
    req.log.error({ err }, "GetPerformance error");
    res.status(500).json({ error: "Failed to fetch performance" });
  }
});

router.get("/analytics/planning", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesters = await getUserSemestersWithCourses(req.userId!);
    const allCourses = semesters.flatMap((s) => s.courses);
    const cgpa = computeCgpa(semesters);

    const totalCreditsRequired = 120;
    const creditsEarned = allCourses.reduce((sum, c) => sum + c.creditHours, 0);
    const creditsRemaining = Math.max(0, totalCreditsRequired - creditsEarned);
    const progressPercent = Math.min(100, Math.round((creditsEarned / totalCreditsRequired) * 100));

    const requiredCredits = allCourses
      .filter((c) => c.courseType === "Required")
      .reduce((sum, c) => sum + c.creditHours, 0);
    const electiveCredits = allCourses
      .filter((c) => c.courseType === "Elective")
      .reduce((sum, c) => sum + c.creditHours, 0);
    const generalCredits = allCourses
      .filter((c) => c.courseType === "General")
      .reduce((sum, c) => sum + c.creditHours, 0);

    const milestones = [
      { label: "100 Level Complete", achieved: creditsEarned >= 30, description: "30 credit units completed" },
      { label: "200 Level Complete", achieved: creditsEarned >= 60, description: "60 credit units completed" },
      { label: "300 Level Complete", achieved: creditsEarned >= 90, description: "90 credit units completed" },
      { label: "400 Level Complete", achieved: creditsEarned >= 120, description: "120 credit units completed" },
      { label: "CGPA above 3.5", achieved: cgpa >= 3.5, description: "Second Class Upper standing" },
      { label: "CGPA above 4.5", achieved: cgpa >= 4.5, description: "First Class standing" },
    ];

    res.json({
      totalCreditsRequired,
      creditsEarned,
      creditsRemaining,
      progressPercent,
      requiredCredits,
      electiveCredits,
      generalCredits,
      milestones,
    });
  } catch (err) {
    req.log.error({ err }, "GetPlanning error");
    res.status(500).json({ error: "Failed to fetch planning data" });
  }
});

export default router;
