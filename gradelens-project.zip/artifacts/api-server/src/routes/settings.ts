import { Router } from "express";
import { db, userSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { authenticateToken, type AuthRequest } from "../middlewares/auth";
import { UpdateSettingsBody } from "@workspace/api-zod";

const router = Router();

router.get("/settings", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const [settings] = await db
      .select()
      .from(userSettingsTable)
      .where(eq(userSettingsTable.userId, req.userId!))
      .limit(1);

    if (!settings) {
      const [created] = await db
        .insert(userSettingsTable)
        .values({ userId: req.userId! })
        .returning();
      res.json(created);
      return;
    }

    res.json(settings);
  } catch (err) {
    req.log.error({ err }, "GetSettings error");
    res.status(500).json({ error: "Failed to fetch settings" });
  }
});

router.patch("/settings", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const parsed = UpdateSettingsBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input" });
      return;
    }

    const [updated] = await db
      .update(userSettingsTable)
      .set(parsed.data)
      .where(eq(userSettingsTable.userId, req.userId!))
      .returning();

    if (!updated) {
      const [created] = await db
        .insert(userSettingsTable)
        .values({ userId: req.userId!, ...parsed.data })
        .returning();
      res.json(created);
      return;
    }

    res.json(updated);
  } catch (err) {
    req.log.error({ err }, "UpdateSettings error");
    res.status(500).json({ error: "Failed to update settings" });
  }
});

export default router;
