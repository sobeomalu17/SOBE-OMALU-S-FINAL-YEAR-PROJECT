import { Router } from "express";
import { db, semestersTable, coursesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { authenticateToken, type AuthRequest } from "../middlewares/auth";
import { calculateGpa } from "../lib/gpa";
import { CreateSemesterBody } from "@workspace/api-zod";

const router = Router();

router.get("/semesters", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesters = await db
      .select()
      .from(semestersTable)
      .where(eq(semestersTable.userId, req.userId!))
      .orderBy(semestersTable.createdAt);
    res.json(
      semesters.map((s) => ({
        ...s,
        semesterGpa: parseFloat(String(s.semesterGpa)),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "GetSemesters error");
    res.status(500).json({ error: "Failed to fetch semesters" });
  }
});

router.post("/semesters", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const parsed = CreateSemesterBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid input" });
      return;
    }
    const { academicYear, semesterType } = parsed.data;

    const [semester] = await db
      .insert(semestersTable)
      .values({ userId: req.userId!, academicYear, semesterType })
      .returning();

    res.status(201).json({
      ...semester,
      semesterGpa: parseFloat(String(semester.semesterGpa)),
    });
  } catch (err) {
    req.log.error({ err }, "CreateSemester error");
    res.status(500).json({ error: "Failed to create semester" });
  }
});

router.get("/semesters/:semesterId", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesterId = parseInt(req.params.semesterId);
    const [semester] = await db
      .select()
      .from(semestersTable)
      .where(and(eq(semestersTable.id, semesterId), eq(semestersTable.userId, req.userId!)))
      .limit(1);

    if (!semester) {
      res.status(404).json({ error: "Semester not found" });
      return;
    }

    const courses = await db
      .select()
      .from(coursesTable)
      .where(eq(coursesTable.semesterId, semesterId));

    res.json({
      ...semester,
      semesterGpa: parseFloat(String(semester.semesterGpa)),
      courses: courses.map((c) => ({
        ...c,
        gradePoints: parseFloat(String(c.gradePoints)),
      })),
    });
  } catch (err) {
    req.log.error({ err }, "GetSemester error");
    res.status(500).json({ error: "Failed to fetch semester" });
  }
});

router.delete("/semesters/:semesterId", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const semesterId = parseInt(req.params.semesterId);
    const [semester] = await db
      .select()
      .from(semestersTable)
      .where(and(eq(semestersTable.id, semesterId), eq(semestersTable.userId, req.userId!)))
      .limit(1);

    if (!semester) {
      res.status(404).json({ error: "Semester not found" });
      return;
    }

    await db.delete(semestersTable).where(eq(semestersTable.id, semesterId));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "DeleteSemester error");
    res.status(500).json({ error: "Failed to delete semester" });
  }
});

export async function recalculateSemesterGpa(semesterId: number) {
  const courses = await db
    .select()
    .from(coursesTable)
    .where(eq(coursesTable.semesterId, semesterId));

  const parsed = courses.map((c) => ({
    creditHours: c.creditHours,
    gradePoints: parseFloat(String(c.gradePoints)),
  }));

  const gpa = calculateGpa(parsed);
  const totalCredits = parsed.reduce((sum, c) => sum + c.creditHours, 0);

  await db
    .update(semestersTable)
    .set({ semesterGpa: String(gpa), totalCredits })
    .where(eq(semestersTable.id, semesterId));

  return { gpa, totalCredits };
}

export default router;
