import { Router } from "express";
import { db, semestersTable, coursesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { authenticateToken, type AuthRequest } from "../middlewares/auth";
import { calculateGpa, getGradePoints } from "../lib/gpa";
import { PredictGpaBody, CalculateTargetBody } from "@workspace/api-zod";

const router = Router();

async function getUserCgpaData(userId: number) {
  const semesters = await db.select().from(semestersTable).where(eq(semestersTable.userId, userId));
  const allCourses = await Promise.all(
    semesters.map((s) => db.select().from(coursesTable).where(eq(coursesTable.semesterId, s.id)))
  );
  const flat = allCourses.flat().map((c) => ({
    creditHours: c.creditHours,
    gradePoints: parseFloat(String(c.gradePoints)),
  }));
  const totalCredits = flat.reduce((sum, c) => sum + c.creditHours, 0);
  const totalPoints = flat.reduce((sum, c) => sum + c.creditHours * c.gradePoints, 0);
  const cgpa = calculateGpa(flat);
  return { cgpa, totalCredits, totalPoints };
}

router.post("/predictor/gpa", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const parsed = PredictGpaBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input" });
      return;
    }

    const { courses } = parsed.data;
    const { cgpa: currentCgpa, totalCredits, totalPoints } = await getUserCgpaData(req.userId!);

    const projectedCourses = courses.map((c) => ({
      creditHours: c.creditHours,
      gradePoints: getGradePoints(c.expectedGrade),
    }));

    const projectedSemesterGpa = calculateGpa(projectedCourses);
    const addedCredits = projectedCourses.reduce((sum, c) => sum + c.creditHours, 0);
    const addedPoints = projectedCourses.reduce((sum, c) => sum + c.creditHours * c.gradePoints, 0);
    const totalCreditsAfter = totalCredits + addedCredits;
    const projectedCgpa =
      totalCreditsAfter > 0
        ? Math.round(((totalPoints + addedPoints) / totalCreditsAfter) * 100) / 100
        : 0;

    res.json({
      projectedSemesterGpa,
      projectedCgpa,
      currentCgpa,
      totalCreditsAfter,
    });
  } catch (err) {
    req.log.error({ err }, "PredictGpa error");
    res.status(500).json({ error: "Failed to predict GPA" });
  }
});

router.post("/predictor/target", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const parsed = CalculateTargetBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid input" });
      return;
    }

    const { targetCgpa, remainingCredits } = parsed.data;
    const { cgpa: currentCgpa, totalCredits, totalPoints } = await getUserCgpaData(req.userId!);

    const maxScale = 5.0;
    let requiredAverageGradePoint = 0;
    let feasible = false;
    let message = "";

    if (remainingCredits <= 0) {
      message = "No remaining credits specified.";
      requiredAverageGradePoint = 0;
      feasible = false;
    } else {
      const totalRequired = targetCgpa * (totalCredits + remainingCredits);
      const needed = totalRequired - totalPoints;
      requiredAverageGradePoint = Math.round((needed / remainingCredits) * 100) / 100;

      if (requiredAverageGradePoint <= maxScale && requiredAverageGradePoint >= 0) {
        feasible = true;
        if (requiredAverageGradePoint >= 4.5) {
          message = `You need an average of ${requiredAverageGradePoint.toFixed(2)} grade points (A grades) in all remaining courses. This is achievable but requires consistent excellent performance.`;
        } else if (requiredAverageGradePoint >= 3.5) {
          message = `You need an average of ${requiredAverageGradePoint.toFixed(2)} grade points (B-A grades) in remaining courses. This is a realistic target with consistent effort.`;
        } else {
          message = `You need an average of ${requiredAverageGradePoint.toFixed(2)} grade points in remaining courses. This is achievable with steady performance.`;
        }
      } else if (requiredAverageGradePoint < 0) {
        feasible = true;
        requiredAverageGradePoint = 0;
        message = `You have already surpassed a CGPA of ${targetCgpa}. Keep up the excellent work!`;
      } else {
        feasible = false;
        message = `A CGPA of ${targetCgpa} is not mathematically achievable with ${remainingCredits} credits remaining, even with perfect grades. Consider adjusting your target.`;
      }
    }

    res.json({
      requiredAverageGradePoint,
      feasible,
      currentCgpa,
      targetCgpa,
      remainingCredits,
      message,
    });
  } catch (err) {
    req.log.error({ err }, "CalculateTarget error");
    res.status(500).json({ error: "Failed to calculate target" });
  }
});

export default router;
