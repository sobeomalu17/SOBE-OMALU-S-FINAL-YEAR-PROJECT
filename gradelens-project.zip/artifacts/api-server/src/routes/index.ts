import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import semestersRouter from "./semesters";
import coursesRouter from "./courses";
import analyticsRouter from "./analytics";
import predictorRouter from "./predictor";
import settingsRouter from "./settings";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(semestersRouter);
router.use(coursesRouter);
router.use(analyticsRouter);
router.use(predictorRouter);
router.use(settingsRouter);

export default router;
