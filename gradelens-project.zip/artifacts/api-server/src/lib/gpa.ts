const GRADE_SCALE_5: Record<string, number> = {
  A: 5.0,
  B: 4.0,
  C: 3.0,
  D: 2.0,
  E: 1.0,
  F: 0.0,
};

const GRADE_SCALE_4: Record<string, number> = {
  A: 4.0,
  B: 3.0,
  C: 2.0,
  D: 1.0,
  E: 0.0,
  F: 0.0,
};

export function getGradePoints(grade: string, scale: "5.0" | "4.0" = "5.0"): number {
  const normalized = grade.toUpperCase().trim();
  if (scale === "4.0") return GRADE_SCALE_4[normalized] ?? 0;
  return GRADE_SCALE_5[normalized] ?? 0;
}

export function calculateGpa(
  courses: { creditHours: number; gradePoints: number }[]
): number {
  const graded = courses.filter((c) => c.gradePoints >= 0);
  const totalCredits = graded.reduce((sum, c) => sum + c.creditHours, 0);
  const totalPoints = graded.reduce((sum, c) => sum + c.creditHours * c.gradePoints, 0);
  if (totalCredits === 0) return 0;
  return Math.round((totalPoints / totalCredits) * 100) / 100;
}

export function getDegreeClass(cgpa: number): string {
  if (cgpa >= 4.5) return "First Class";
  if (cgpa >= 3.5) return "Second Class Upper";
  if (cgpa >= 2.4) return "Second Class Lower";
  if (cgpa >= 1.5) return "Third Class";
  if (cgpa >= 1.0) return "Pass";
  return "Fail";
}
