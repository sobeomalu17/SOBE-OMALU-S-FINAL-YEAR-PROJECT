# GradeLens — Student Grade Dashboard

A full-stack student grade management dashboard for Sobechukwu Emmanuel Omalu's Pan-Atlantic University final year project. Students track grades, GPA, analytics and simulate future performance using the Nigerian 5.0 grading scale.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied at /api)
- `pnpm --filter @workspace/gradelens run dev` — run the frontend (port 19758, proxied at /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — JWT signing secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite, Wouter (routing), Recharts (charts), Tailwind CSS
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Auth: JWT (stored in localStorage as `gradelens_token`)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/` — DB tables: users, semesters, courses, userSettings
- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth for API)
- `lib/api-zod/src/generated/api.ts` — Generated Zod schemas (run codegen to update)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/api-server/src/middlewares/auth.ts` — JWT middleware + token generator
- `artifacts/api-server/src/lib/gpa.ts` — GPA calculation (5.0 scale)
- `artifacts/gradelens/src/pages/` — All 9 frontend pages
- `artifacts/gradelens/src/contexts/AuthContext.tsx` — Auth state (JWT)
- `artifacts/gradelens/src/lib/api.ts` — Fetch wrapper with auth headers

## Architecture decisions

- Nigerian 5.0 grade scale: A=5, B=4, C=3, D=2, E=1, F=0
- JWT stored in localStorage under key `gradelens_token`; passed as `Authorization: Bearer` header
- GPA recalculates automatically whenever a course is added, updated, or deleted
- All routes prefixed at `/api` via the shared reverse proxy
- Frontend uses `import.meta.env.BASE_URL` to prefix API calls (proxy-safe)

## Product

- **Login / Register** — JWT-based student auth with matric number, program, year
- **Dashboard** — CGPA overview, GPA trend line chart, grade pie chart, recent semesters
- **Semesters** — CRUD semesters (academic year + type)
- **Semester Detail** — CRUD courses per semester; inline edit; grade scale reference
- **Analytics → Performance** — GPA progression, grade distribution, best/weakest course
- **Analytics → Planning** — Degree progress bar, milestones, credit breakdown by type
- **GPA Predictor** — Simulate next semester grades → projected CGPA impact
- **Target Calculator** — Enter target CGPA + remaining credits → required grade average
- **Settings** — Grade scale, target CGPA, theme preference, notification toggles

## Demo Account

- Email: test@test.com / Password: test123
- Pre-seeded with 3 semesters and 15 courses of realistic data

## Gotchas

- Always run `pnpm --filter @workspace/db run push` after schema changes
- Zod schemas from codegen use PascalCase Body suffix: `RegisterBody`, `LoginBody`, etc.
- Do NOT call `pnpm dev` at workspace root — use workflow names via restart_workflow

## User preferences

_Populate as needed._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
